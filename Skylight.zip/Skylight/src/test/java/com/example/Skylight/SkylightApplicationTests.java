package com.example.Skylight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkylightApplicationTests {

	@Test
	void contextLoads() {
	}

}
